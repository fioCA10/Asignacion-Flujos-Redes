from itertools import permutations

analistas = ["Andrea", "Beatriz", "Carlos", "Daniel", "Esteban"]
operaciones = ["MT103", "MT202", "MT700", "MT760", "MT940"]

tiempos = {
    "Andrea":  {"MT103": 25, "MT202": 30, "MT700": None, "MT760": None, "MT940": 20},
    "Beatriz": {"MT103": 35, "MT202": 28, "MT700": 40, "MT760": 45, "MT940": 22},
    "Carlos":  {"MT103": 40, "MT202": 45, "MT700": 35, "MT760": 30, "MT940": 25},
    "Daniel":  {"MT103": 30, "MT202": 32, "MT700": 50, "MT760": None, "MT940": 18},
    "Esteban": {"MT103": None, "MT202": None, "MT700": 30, "MT760": 28, "MT940": 30},
}

mejor_tiempo = None
mejor_asignacion = None

for permutacion in permutations(operaciones):
    total = 0
    asignacion = []
    factible = True

    for analista, operacion in zip(analistas, permutacion):
        tiempo = tiempos[analista][operacion]
        if tiempo is None:
            factible = False
            break
        total += tiempo
        asignacion.append((analista, operacion, tiempo))

    if factible and (mejor_tiempo is None or total < mejor_tiempo):
        mejor_tiempo = total
        mejor_asignacion = asignacion

print("Solucion optima")
print("----------------")
for analista, operacion, tiempo in mejor_asignacion:
    print(f"{analista:8s} -> {operacion:5s} = {tiempo} minutos")
print(f"\nTiempo total minimo = {mejor_tiempo} minutos")
