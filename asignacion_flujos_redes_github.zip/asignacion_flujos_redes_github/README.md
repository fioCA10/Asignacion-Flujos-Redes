# Modelo de asignación - Flujos de redes

Este repositorio contiene la solución del problema de asignación de 5 analistas a 5 operaciones. El objetivo es minimizar el tiempo total de ejecución, respetando las restricciones de compliance indicadas en clase.

## Resultado óptimo

| Analista | Operación asignada | Tiempo (min) |
|---|---:|---:|
| Andrea | MT103 | 25 |
| Beatriz | MT202 | 28 |
| Carlos | MT760 | 30 |
| Daniel | MT940 | 18 |
| Esteban | MT700 | 30 |

**Tiempo total mínimo:** 131 minutos.

## Archivos

- `modelo.mod`: modelo matemático en AMPL.
- `datos.dat`: datos del problema en AMPL.
- `run.run`: archivo para ejecutar el modelo en AMPL.
- `resolver_python.py`: solución alternativa en Python por enumeración.
- `requirements.txt`: dependencias para ejecutar el script de Python.
- `solucion.txt`: resumen de la solución óptima.

## Cómo correrlo en AMPL

```bash
ampl run.run
```

## Cómo correrlo en Python

```bash
python resolver_python.py
```

## Modelo matemático

Variable binaria:

```text
x[i,j] = 1 si el analista i realiza la operación j
x[i,j] = 0 en caso contrario
```

Función objetivo:

```text
Minimizar Z = suma de tiempos de las asignaciones realizadas
```

Restricciones principales:

```text
Cada operación debe ser asignada exactamente a un analista.
Cada analista debe realizar exactamente una operación.
Las asignaciones prohibidas por compliance se fuerzan a cero.
```
