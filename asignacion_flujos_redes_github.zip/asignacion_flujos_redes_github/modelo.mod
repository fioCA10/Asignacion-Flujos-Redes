# Modelo de asignacion de analistas a operaciones

set ANALISTAS;
set OPERACIONES;

param tiempo {ANALISTAS, OPERACIONES} >= 0;
param permitido {ANALISTAS, OPERACIONES} binary;

var x {ANALISTAS, OPERACIONES} binary;

minimize Z:
    sum {i in ANALISTAS, j in OPERACIONES} tiempo[i,j] * x[i,j];

subject to UnaOperacionPorAnalista {i in ANALISTAS}:
    sum {j in OPERACIONES} x[i,j] = 1;

subject to UnAnalistaPorOperacion {j in OPERACIONES}:
    sum {i in ANALISTAS} x[i,j] = 1;

subject to Compliance {i in ANALISTAS, j in OPERACIONES}:
    x[i,j] <= permitido[i,j];
